package com.siac070.SIACProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SiacProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
