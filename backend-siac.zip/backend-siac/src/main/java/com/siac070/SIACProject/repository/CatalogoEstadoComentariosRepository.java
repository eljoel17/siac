package com.siac070.SIACProject.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.siac070.SIACProject.model.CatalogoEstadoComentarios;

public interface CatalogoEstadoComentariosRepository extends JpaRepository<CatalogoEstadoComentarios, Long> {    
}
