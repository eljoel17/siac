package com.siac070.SIACProject.repository;

import com.siac070.SIACProject.model.Calle;
import com.siac070.SIACProject.model.Colonia;
import com.siac070.SIACProject.model.Localidad;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LocalidadRepository extends JpaRepository<Localidad, Integer> {
    Localidad findByCalleAndColonia(Calle calle, Colonia colonia);
}
