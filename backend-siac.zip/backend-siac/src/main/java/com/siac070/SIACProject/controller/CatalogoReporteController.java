package com.siac070.SIACProject.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.siac070.SIACProject.model.CatalogoReporte;
import com.siac070.SIACProject.service.CatalogoReportesService;

@RestController
@CrossOrigin
public class CatalogoReporteController {

    @Autowired
    private CatalogoReportesService catalogoReportesService;

    @PostMapping("/crear_catalogo_reportes")
    public ResponseEntity<Object> crearCatalogoReportes(@RequestBody CatalogoReporte catalogoReportes) {
        boolean exito = catalogoReportesService.crearCatalogoReportes(catalogoReportes);
        Map<String, Object> response = new HashMap<>();
        if (exito) {
            response.put("message", "Catálogo de reportes creado con éxito");
            response.put("success", true);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } else {
            response.put("message", "Error al crear el catálogo de reportes");
            response.put("success", false);
        }
        response.put("success", false);
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @PostMapping("/actualizar_catalogo_reportes/{id}")
    public ResponseEntity<Object> actualizarCatalogoReportes(@RequestBody CatalogoReporte catalogoReportes, @PathVariable Long id) {
        boolean exito = catalogoReportesService.actualizarCatalogoReportes(id,catalogoReportes);
        Map<String, Object> response = new HashMap<>();
        if (exito) {
            response.put("message", "Catálogo de reportes actualizado con éxito");
            response.put("success", true);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else {
            response.put("message", "Error al actualizar el catálogo de reportes");
            response.put("success", false);
        }
        response.put("success", false);
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @DeleteMapping("/eliminar_catalogo_reportes/{id}")
    public ResponseEntity<Object> eliminarCatalogoReportes(@PathVariable Long id) {
        boolean exito = catalogoReportesService.eliminarCatalogoReporte(id);
        Map<String, Object> response = new HashMap<>();
        if (exito) {
            response.put("message", "Catálogo de reportes eliminado con éxito");
            response.put("success", true);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else {
            response.put("message", "Error al eliminar el catálogo de reportes");
            response.put("success", false);
        }
        response.put("success", false);
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @GetMapping("/catalogo_reportes")
    public List<CatalogoReporte> obtenerCatalogoReportes() {
        return catalogoReportesService.obtenerCatalogoReportes();
    }
 
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<Object> handleException(HttpMessageNotReadableException e) {
        Map<String, Object> response = new HashMap<>();
        response.put("message", "Error al actualizar el catálogo de reportes");
        response.put("success", false);
        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }
}
