package com.siac070.SIACProject.repository;

import com.siac070.SIACProject.model.CatDependencia;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CatDependenciaRepository extends JpaRepository<CatDependencia, Integer> {
}
