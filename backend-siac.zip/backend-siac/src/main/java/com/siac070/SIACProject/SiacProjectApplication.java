package com.siac070.SIACProject;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SiacProjectApplication {
    public static void main(String[] args) {
        SpringApplication.run(SiacProjectApplication.class, args);
    }
}
