package com.siac070.SIACProject.dto;

import com.siac070.SIACProject.model.CatUsuario;
import com.siac070.SIACProject.model.CatEstatusUsuario;

public class LoginResponse {

    private Long id;
    private String nombre;
    private String apellidoPaterno;
    private String apellidoMaterno;
    private String correo;
    private String telefono;
    private CatUsuario catUsuario;
    private CatEstatusUsuario catEstatusUsuario;
    private String token;
    private String message;

    // Constructor
    public LoginResponse(Long id, String nombre, String apellidoPaterno, String apellidoMaterno, 
                         String correo, String telefono, CatUsuario catUsuario, 
                         CatEstatusUsuario catEstatusUsuario, String token, String message) {
        this.id = id;
        this.nombre = nombre;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.correo = correo;
        this.telefono = telefono;
        this.catUsuario = catUsuario;
        this.catEstatusUsuario = catEstatusUsuario;
        this.token = token;
        this.message = message;
    }

    // Getters
    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellidoPaterno() {
        return apellidoPaterno;
    }

    public String getApellidoMaterno() {
        return apellidoMaterno;
    }

    public String getCorreo() {
        return correo;
    }

    public String getTelefono() {
        return telefono;
    }

    public CatUsuario getCatUsuario() {
        return catUsuario;
    }

    public CatEstatusUsuario getCatEstatusUsuario() {
        return catEstatusUsuario;
    }

    public String getToken() {
        return token;
    }

    public String getMessage() {
        return message;
    }

    // Setters
    public void setId(Long id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellidoPaterno(String apellidoPaterno) {
        this.apellidoPaterno = apellidoPaterno;
    }

    public void setApellidoMaterno(String apellidoMaterno) {
        this.apellidoMaterno = apellidoMaterno;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setCatUsuario(CatUsuario catUsuario) {
        this.catUsuario = catUsuario;
    }

    public void setCatEstatusUsuario(CatEstatusUsuario catEstatusUsuario) {
        this.catEstatusUsuario = catEstatusUsuario;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
