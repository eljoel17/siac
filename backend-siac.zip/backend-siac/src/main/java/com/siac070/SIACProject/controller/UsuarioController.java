package com.siac070.SIACProject.controller;

import com.siac070.SIACProject.dto.LoginResponse;
import com.siac070.SIACProject.model.Usuario;
import com.siac070.SIACProject.repository.UsuarioRepository;
import com.siac070.SIACProject.service.UsuarioService;
import com.siac070.SIACProject.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Optional;
import java.util.HashMap;

@RestController
@CrossOrigin
@RequestMapping("/api/usuarios")
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @PostMapping("/register")
    public ResponseEntity<String> registerUsuario(@RequestBody Usuario usuario) {
        try {
            // Verificar si el correo ya está en uso
            if (usuarioService.findByCorreo(usuario.getCorreo()).isPresent()) {
                System.out.println("Correo ya registrado: " + usuario.getCorreo());
                return new ResponseEntity<>("El correo ya está en uso.", HttpStatus.CONFLICT);
            }

            // Guardar el usuario (encriptación de la contraseña ya está en el servicio)
            usuarioService.saveUsuario(usuario);

            System.out.println("Usuario registrado exitosamente: " + usuario.getCorreo());
            return new ResponseEntity<>("Usuario registrado exitosamente", HttpStatus.CREATED);
        } catch (IllegalArgumentException e) {
            System.out.println("Error al registrar usuario: " + e.getMessage());
            return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
        } catch (Exception e) {
            System.out.println("Error general al registrar usuario: " + e.getMessage());
            return new ResponseEntity<>("Error al registrar usuario", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

   @PostMapping("/login")
public ResponseEntity<LoginResponse> login(@RequestBody Map<String, String> loginData) {
    String correo = loginData.get("correo");
    String contrasena = loginData.get("contrasena");

    Optional<Usuario> usuarioOptional = usuarioService.findByCorreo(correo);

    if (usuarioOptional.isPresent()) {
        Usuario usuario = usuarioOptional.get();

        // Verificar la contraseña usando passwordEncoder.matches()
        boolean isPasswordValid = passwordEncoder.matches(contrasena, usuario.getContrasena());
        if (isPasswordValid) {
            // Obtener detalles del usuario
            UserDetails userDetails = usuarioService.loadUserByUsername(correo);

            // Generar JWT
            String token = jwtUtil.generateToken(userDetails);

            // Crear el objeto de respuesta ordenada
            LoginResponse response = new LoginResponse(
                usuario.getId(),
                usuario.getNombre(),
                usuario.getApellidoPaterno(),
                usuario.getApellidoMaterno(),
                usuario.getCorreo(),
                usuario.getTelefono(),
                usuario.getCatUsuario(),
                usuario.getCatEstatusUsuario(),
                token,
                "Login exitoso"
            );

            return new ResponseEntity<>(response, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(null, HttpStatus.UNAUTHORIZED);
        }
    } else {
        return new ResponseEntity<>(null, HttpStatus.UNAUTHORIZED);
    }
}


@GetMapping("/oauth2/details")
    public Map<String, Object> getUserDetails(@AuthenticationPrincipal OAuth2User oAuth2User) {
        // Extraer los detalles del usuario autenticado mediante OAuth2 (Google)
        Map<String, Object> userDetails = Map.of(
            "message", "Login exitoso con Google",
            "name", oAuth2User.getAttribute("name"),
            "email", oAuth2User.getAttribute("email"),
            "picture", oAuth2User.getAttribute("picture")
        );
        
        return userDetails;
    }




}

