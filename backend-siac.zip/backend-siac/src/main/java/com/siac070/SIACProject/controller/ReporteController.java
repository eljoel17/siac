package com.siac070.SIACProject.controller;

import com.siac070.SIACProject.model.Reporte;
import com.siac070.SIACProject.service.ReporteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.HashMap;
import java.util.Map;

@RestController
@CrossOrigin
@RequestMapping("/api/reportes")
public class ReporteController {

    @Autowired
    private ReporteService reporteService;

    @GetMapping
    public List<Reporte> getAllReportes() {
        return reporteService.getAllReportes();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Reporte> getReporteById(@PathVariable Long id) {
        Optional<Reporte> reporte = reporteService.getReporteById(id);
        return reporte.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public Reporte createReporte(@RequestBody Reporte reporte) {
        return reporteService.saveReporte(reporte);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Reporte> updateReporte(@PathVariable Long id, @RequestBody Reporte reporteDetails) {
        Optional<Reporte> reporte = reporteService.getReporteById(id);

        if (reporte.isPresent()) {
            Reporte updatedReporte = reporte.get();
            updatedReporte.setCoordenada_x(reporteDetails.getCoordenada_x());
            updatedReporte.setCoordenada_y(reporteDetails.getCoordenada_y());
            updatedReporte.setRuta_imagen(reporteDetails.getRuta_imagen());
            updatedReporte.setDescripcion(reporteDetails.getDescripcion());
            updatedReporte.setCalificacion(reporteDetails.getCalificacion());
            updatedReporte.setFecha_creacion(reporteDetails.getFecha_creacion());
            updatedReporte.setClave(reporteDetails.getClave());
            updatedReporte.setId_cat_reportes(reporteDetails.getId_cat_reportes());
            updatedReporte.setLocalidades_id(reporteDetails.getLocalidades_id());
            return ResponseEntity.ok(reporteService.saveReporte(updatedReporte));
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteReporte(@PathVariable Long id) {
        reporteService.deleteReporte(id);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/crear_reporte")
    public ResponseEntity<Object> crearReporte(@RequestBody Reporte reporte) {

        String coloniaNombre = reporte.getColoniaNombre();
        String calleNombre = reporte.getCalleNombre();
        int notificacionCorreo = reporte.getNotificacionCorreo();
        Long idUsuarioReporte = reporte.getIdUsuariosReporte();

        Map<String, Object> response = new HashMap<>();

        try {
            Long idReporte = reporteService.crearReporte(reporte, coloniaNombre, calleNombre, notificacionCorreo,
                    idUsuarioReporte);
            if (idReporte != null) {
                response.put("message", "Reporte creado con éxito");
                response.put("success", true);
                response.put("idreporte", idReporte);
                return new ResponseEntity<>(response, HttpStatus.CREATED);
            } else {
                response.put("message", "Error al crear el reporte");
                response.put("success", false);
                return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
            }

        } catch (Exception e) {
            response.put("message", "Error al crear el reporte");
            response.put("success", false);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/agregar_calificacion/{id}")
    public ResponseEntity<Object> agregarCalificacion(@PathVariable Long id, @RequestBody Reporte calificacion) {
        boolean exito = reporteService.agregarCalificacion(id, calificacion.getCalificacion());
        Map<String, Object> response = new HashMap<>();
        if (exito) {
            response.put("message", "Calificación agregada con éxito");
            response.put("success", true);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else {
            response.put("message", "Error al agregar la calificación");
        }
        response.put("success", false);
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @PostMapping("/actualizar_reporte/{id}")
    public ResponseEntity<Object> actualizarReporte(@PathVariable Long id, @RequestBody Reporte reporteDetalles) {

        boolean exito = reporteService.actualizarReporte(id, reporteDetalles);
        Map<String, Object> response = new HashMap<>();
        if (exito) {
            response.put("message", "Reporte actualizado con éxito");
            response.put("success", true);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else {
            response.put("message", "Error al actualizar el reporte");
        }
        response.put("success", false);
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);

    }

    @GetMapping("/usuario/{idUsuarioReporte}")
    public ResponseEntity<List<Reporte>> obtenerReportesPorUsuario(@PathVariable Long idUsuarioReporte) {
        List<Reporte> reportes = reporteService.obtenerReportesPorUsuario(idUsuarioReporte);

        if (reportes != null) {
            return ResponseEntity.ok(reportes);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/reporte_mes_actual")
    public ResponseEntity<List<Reporte>> obtenerReportesMesActual() {
        List<Reporte> reportes = reporteService.obtenerReportesMesActual();
        if (!reportes.isEmpty()) { // Verificar si la lista tiene elementos
            return ResponseEntity.ok(reportes);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

}
