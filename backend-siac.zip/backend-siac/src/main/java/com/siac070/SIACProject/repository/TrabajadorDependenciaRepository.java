package com.siac070.SIACProject.repository;


import com.siac070.SIACProject.model.CatDependencia;
import com.siac070.SIACProject.model.TrabajadorDependencia;
import com.siac070.SIACProject.model.Usuario;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface TrabajadorDependenciaRepository extends JpaRepository<TrabajadorDependencia, Integer> {
    Optional<TrabajadorDependencia> findByUsuarioAndDependencia(Usuario usuario, CatDependencia dependencia);
}
