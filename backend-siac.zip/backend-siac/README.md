# backend-siac

Documentacion

Toda la documentacion esta disponible en 
Es necesario realizar el login para que se puedan cragar todos los controlladores
http://localhost:8080/swagger-ui/index.html




http://localhost:8080/api/usuarios/register

Registrar Usuario JSON POST

{
  "nombre": "Juan",
  "apellidoPaterno": "Perez",
  "apellidoMaterno": "Gomez",
  "correo": "christian.perez@example.com",
  "contrasena": "123456",
  "telefono": "555-1234"
}


http://localhost:8080/api/usuarios/login

Se envia por JSON
{
"correo": "christiantronix@gmail.com",
"contrasena": "12345678"
}

y se recibe

{
    "id": 13,
    "nombre": "Christian",
    "apellidoPaterno": "Gonzalez",
    "apellidoMaterno": "Garcia",
    "correo": "christiantronix@gmail.com",
    "telefono": null,
    "catUsuario": {
        "id": 1,
        "nombre": "General"
    },
    "catEstatusUsuario": {
        "id": 1,
        "estatus": "Activo"
    },
    "token": "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJjaHJpc3RpYW50cm9uaXhAZ21haWwuY29tIiwiaWF0IjoxNzI5MTg4Mjk1LCJleHAiOjE3MjkxOTE4OTV9.w0MurlCV0moy8oUPI-Uy-iXbbzKjU5qdAP2g0npwbUE",
    "message": "Login exitoso"
}

El login con github se hace haciendo un Get
http://localhost:8080/oauth2/authorization/github

Y el login por Google se hace haciendo un Get
http://localhost:8080/oauth2/authorization/google

Cuando se obtiene un login valido se obtiene como respuesta, EL TOKEN NO ES NECESARIO ENVIARLO 

{"token":"eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJjaHJpc3RpYW50cm9uaXhAZ21haWwuY29tIiwiaWF0IjoxNzI5MTg4MDYyLCJleHAiOjE3MjkxOTE2NjJ9.-9d2f5uTndUoR5eEBrAWOuqKOfBHVPexorGwjRAJ1zM","message":"Login exitoso con Google","picture":"https://lh3.googleusercontent.com/a/ACg8ocKnMJyKLa7SFyuq3KHnW6HH_1TItrM8bV4fECPg5nrgyTo1eEbV=s96-c","email":"christiantronix@gmail.com","name":"Christian Gonzalez"}



Por default se asigna categoría 1 estatus 1 


implementation 'org.springframework.boot:spring-boot-starter-data-jpa'
	implementation 'org.springframework.boot:spring-boot-starter-web'
	implementation 'org.springframework.boot:spring-boot-starter-security' // Para manejo de autenticación y seguridad
	implementation 'org.springframework.boot:spring-boot-starter-thymeleaf' // Para Thymeleaf (si utilizas vistas Thymeleaf)
	implementation 'com.itextpdf:itext7-core:7.2.3' // Para la generación de PDFs
	implementation 'org.springframework.security:spring-security-crypto' // Para encriptación de contraseñas
    implementation 'org.springframework.boot:spring-boot-starter-oauth2-client'
    implementation 'org.springframework.boot:spring-boot-starter-oauth2-resource-server'
	implementation 'org.springframework.boot:spring-boot-starter-security'
    implementation 'org.springframework.boot:spring-boot-starter-data-jpa'
    implementation 'org.springframework.boot:spring-boot-starter-web'
    implementation 'org.springframework.security:spring-security-core'
    implementation 'org.springframework.security:spring-security-web'
    implementation 'org.springframework.security:spring-security-config'
	implementation 'org.apache.tomcat.embed:tomcat-embed-core'
	implementation 'io.jsonwebtoken:jjwt-api:0.11.5'
	runtimeOnly 'io.jsonwebtoken:jjwt-impl:0.11.5'
	runtimeOnly 'io.jsonwebtoken:jjwt-jackson:0.11.5' // Para usar Jackson en lugar de Gson
	implementation 'jakarta.xml.bind:jakarta.xml.bind-api:3.0.1'
	implementation 'org.glassfish.jaxb:jaxb-runtime:3.0.1'
	implementation 'javax.servlet:javax.servlet-api:3.1.0'
	implementation 'jakarta.servlet:jakarta.servlet-api:5.0.0'
    implementation 'org.glassfish.jaxb:jaxb-runtime:2.3.3'
	compileOnly 'org.projectlombok:lombok'
	developmentOnly 'org.springframework.boot:spring-boot-devtools'
	runtimeOnly 'com.mysql:mysql-connector-j'
	annotationProcessor 'org.projectlombok:lombok'
	testImplementation 'org.springframework.boot:spring-boot-starter-test'
	testRuntimeOnly 'org.junit.platform:junit-platform-launcher'


application.properties

spring.application.name=SIACProject


spring.security.user.name=admin
spring.security.user.password=admin123


jwt.secret="b78df8b9cbe1a2331e7f7b7f8df4b6f7ac3d9e65d8463b3296a8e5d9a3dfce47"
jwt.expiration=86400000  # 24 horas en milisegundos


server.port=8080
spring.datasource.url=jdbc:mysql://localhost:3306/siac_db
spring.datasource.username=root
spring.datasource.password=root
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver

spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.MySQLDialect

# Configuración de Google OAuth2
spring.security.oauth2.client.registration.google.client-id=125385680335-k96darrl5oeh0aga6mfj77div94dv727.apps.googleusercontent.com
spring.security.oauth2.client.registration.google.client-secret=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
spring.security.oauth2.client.registration.google.scope=email,profile
spring.security.oauth2.client.registration.google.redirect-uri=http://localhost:8080/login/oauth2/code/google
spring.security.oauth2.client.registration.google.client-authentication-method=post
spring.security.oauth2.client.registration.google.authorization-grant-type=authorization_code
spring.security.oauth2.client.provider.google.authorization-uri=https://accounts.google.com/o/oauth2/auth
spring.security.oauth2.client.provider.google.token-uri=https://oauth2.googleapis.com/token
spring.security.oauth2.client.provider.google.user-info-uri=https://www.googleapis.com/oauth2/v3/userinfo
spring.security.oauth2.client.provider.google.user-name-attribute=sub
